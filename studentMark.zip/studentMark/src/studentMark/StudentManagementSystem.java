package studentMark;

import java.sql.*;
import java.util.Scanner;

class DatabaseConnection {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/student_database?useSSL=false&serverTimezone=UTC";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = ""; 

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL JDBC Driver not found: " + e.getMessage());
        }
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
    }
}
    
class StudentDataManager {
    public void createStudent(String studentName, int studentAge, String studentGrade) {
        String sqlQuery = "INSERT INTO students (name, age, grade) VALUES (?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sqlQuery)) {
            statement.setString(1, studentName);
            statement.setInt(2, studentAge);
            statement.setString(3, studentGrade);
            statement.executeUpdate();
            System.out.println("✓ Student added successfully!");
        } catch (SQLException e) {
            System.err.println("Error adding student: " + e.getMessage());
        }
    }

    public void displayAllStudents() {
        String sqlQuery = "SELECT * FROM students ORDER BY id";
        try (Connection connection = DatabaseConnection.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sqlQuery)) {
            System.out.println("\n--- Student Records ---");
            System.out.println("ID | Name | Age | Grade");
            System.out.println("------------------------");
            boolean hasRecords = false;
            while (resultSet.next()) {
                System.out.printf("%-3d | %-15s | %-3d | %s\n",
                        resultSet.getInt("id"),
                        resultSet.getString("name"),
                        resultSet.getInt("age"),
                        resultSet.getString("grade"));
                hasRecords = true;
            }
            if (!hasRecords) {
                System.out.println("No students found in the database.");
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving students: " + e.getMessage());
        }
    }

    public void modifyStudent(int studentId, String studentName, int studentAge, String studentGrade) {
        String sqlQuery = "UPDATE students SET name=?, age=?, grade=? WHERE id=?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sqlQuery)) {
            statement.setString(1, studentName);
            statement.setInt(2, studentAge);
            statement.setString(3, studentGrade);
            statement.setInt(4, studentId);
            int affectedRows = statement.executeUpdate();
            if (affectedRows > 0) {
                System.out.println("✓ Student updated successfully!");
            } else {
                System.out.println("✗ Student not found with ID: " + studentId);
            }
        } catch (SQLException e) {
            System.err.println("Error updating student: " + e.getMessage());
        }
    }

    public void removeStudent(int studentId) {
        String sqlQuery = "DELETE FROM students WHERE id=?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sqlQuery)) {
            statement.setInt(1, studentId);
            int affectedRows = statement.executeUpdate();
            if (affectedRows > 0) {
                System.out.println("✓ Student deleted successfully!");
            } else {
                System.out.println("✗ Student not found with ID: " + studentId);
            }
        } catch (SQLException e) {
            System.err.println("Error deleting student: " + e.getMessage());
        }
    }
    
    public void findStudentsByName(String searchName) {
        String sqlQuery = "SELECT * FROM students WHERE name LIKE ? ORDER BY name";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sqlQuery)) {
            statement.setString(1, "%" + searchName + "%"); 
            ResultSet resultSet = statement.executeQuery();

            System.out.println("\n--- Search Results ---");
            System.out.println("ID | Name | Age | Grade");
            System.out.println("------------------------");
            boolean foundResults = false;
            while (resultSet.next()) {
                System.out.printf("%-3d | %-15s | %-3d | %s\n",
                        resultSet.getInt("id"),
                        resultSet.getString("name"),
                        resultSet.getInt("age"),
                        resultSet.getString("grade"));
                foundResults = true;
            }
            if (!foundResults) {
                System.out.println("No students found matching: '" + searchName + "'");
            }
        } catch (SQLException e) {
            System.err.println("Error searching students: " + e.getMessage());
        }
    }
}

public class StudentManagementSystem {
    private static Scanner inputScanner = new Scanner(System.in);
    private static StudentDataManager studentManager = new StudentDataManager();

    public static void main(String[] args) {
        displayWelcomeMessage();
        
        while (true) {
            displayMainMenu();
            int userChoice = getMenuChoice();
            processUserChoice(userChoice);
        }
    }

    private static void displayWelcomeMessage() {
        System.out.println("====================================");
        System.out.println("   STUDENT MANAGEMENT SYSTEM");
        System.out.println("====================================");
    }

    private static void displayMainMenu() {
        System.out.println("\n--- Main Menu ---");
        System.out.println("1. Add New Student");
        System.out.println("2. View All Students");
        System.out.println("3. Update Student Information");
        System.out.println("4. Remove Student");
        System.out.println("5. Search Students by Name");
        System.out.println("6. Exit Application");
        System.out.print("Please select an option (1-6): ");
    }

    private static int getMenuChoice() {
        while (!inputScanner.hasNextInt()) {
            System.out.println("Invalid input! Please enter a number between 1-6.");
            inputScanner.nextLine();
            System.out.print("Please select an option (1-6): ");
        }
        int choice = inputScanner.nextInt();
        inputScanner.nextLine(); // Consume newline
        return choice;
    }

    private static void processUserChoice(int choice) {
        switch (choice) {
            case 1:
                addNewStudent();
                break;
            case 2:
                studentManager.displayAllStudents();
                break;
            case 3:
                updateStudentRecord();
                break;
            case 4:
                deleteStudentRecord();
                break;
            case 5:
                searchStudentRecords();
                break;
            case 6:
                exitApplication();
                break;
            default:
                System.out.println("Invalid option! Please choose between 1-6.");
        }
    }

    private static void addNewStudent() {
        System.out.println("\n--- Add New Student ---");
        
        String studentName = getValidatedInput("Enter student name: ", "Name cannot be empty");
        int studentAge = getValidatedAge();
        String studentGrade = getValidatedInput("Enter student grade: ", "Grade cannot be empty");
        
        studentManager.createStudent(studentName, studentAge, studentGrade);
    }

    private static void updateStudentRecord() {
        System.out.println("\n--- Update Student ---");
        int studentId = getValidatedId("Enter student ID to update: ");
        
        String newName = getValidatedInput("Enter new name: ", "Name cannot be empty");
        int newAge = getValidatedAge();
        String newGrade = getValidatedInput("Enter new grade: ", "Grade cannot be empty");
        
        studentManager.modifyStudent(studentId, newName, newAge, newGrade);
    }

    private static void deleteStudentRecord() {
        System.out.println("\n--- Remove Student ---");
        int studentId = getValidatedId("Enter student ID to remove: ");
        studentManager.removeStudent(studentId);
    }

    private static void searchStudentRecords() {
        System.out.println("\n--- Search Students ---");
        String searchName = getValidatedInput("Enter name to search: ", "Search term cannot be empty");
        studentManager.findStudentsByName(searchName);
    }

    private static void exitApplication() {
        System.out.println("\nThank you for using Student Management System!");
        System.out.println("Goodbye!");
        inputScanner.close();
        System.exit(0);
    }

    private static String getValidatedInput(String prompt, String errorMessage) {
        String input;
        do {
            System.out.print(prompt);
            input = inputScanner.nextLine().trim();
            if (input.isEmpty()) {
                System.out.println("✗ " + errorMessage);
            }
        } while (input.isEmpty());
        return input;
    }

    private static int getValidatedAge() {
        int age;
        do {
            System.out.print("Enter student age: ");
            while (!inputScanner.hasNextInt()) {
                System.out.println("✗ Age must be a valid number");
                inputScanner.nextLine();
                System.out.print("Enter student age: ");
            }
            age = inputScanner.nextInt();
            inputScanner.nextLine(); // Consume newline
            if (age <= 0) {
                System.out.println("✗ Age must be greater than 0");
            }
        } while (age <= 0);
        return age;
    }

    private static int getValidatedId(String prompt) {
        int id;
        do {
            System.out.print(prompt);
            while (!inputScanner.hasNextInt()) {
                System.out.println("✗ ID must be a valid number");
                inputScanner.nextLine();
                System.out.print(prompt);
            }
            id = inputScanner.nextInt();
            inputScanner.nextLine(); // Consume newline
            if (id <= 0) {
                System.out.println("✗ ID must be greater than 0");
            }
        } while (id <= 0);
        return id;
    }
}
